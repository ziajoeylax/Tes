window.VEXO_CONFIG = {
  brand: 'VEXO',
  welcome: 'قدرت در دستان شما',
  userName: 'کاربر عزیز',
  userLevel: 'سطح کاربری: عادی',
  serverIp: '185.199.110.12',
  version: 'v2.6.7.28',
  supportText: 'پشتیبانی ۲۴/۷ برای تمام نیازهای شما'
};
